<?php $this->load->view('themes/head');?>
<?php $this->load->view($content);?>
<?php $this->load->view('themes/footer');?>