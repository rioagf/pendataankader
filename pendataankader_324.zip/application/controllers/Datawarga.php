<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datawarga extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
     	parent::__construct();
     	$this->load->model('M_datawarga');
 	}

	public function get_data()
	{
		$datawarga = $this->M_datawarga->get__data()->result();
		$data = array(
			'title' => 'Data Warga | RW 01',
			'page' => 'warga/data_warga',
			'data_warga' => $datawarga,
		);
		$this->load->view('web/template', $data);
	}

	public function input_data()
	{
		$data = array(
			'id_data_warga' => $this->input->post('id_data_warga'),
			'no_kk' => $this->input->post('no_kk'),
			'nik' => $this->input->post('nik'),
			'nama_lengkap' => $this->input->post('nama_lengkap'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'tempat_lahir' => $this->input->post('tempat_lahir'),
			'tanggal_lahir' => $this->input->post('tanggal_lahir'),
			'status_perkawinan' => $this->input->post('status_perkawinan'),
			'agama' => $this->input->post('agama'),
			'warganegara' => $this->input->post('warganegara'),
			'pendidikan' => $this->input->post('pendidikan'),
			'kondisi_pekerjaan' => $this->input->post('kondisi_pekerjaan'),
			'pekerjaan_utama' => $this->input->post('pekerjaan_utama'),
			'jamsostek' => $this->input->post('jamsostek'),
			'penghasilan' => $this->input->post('penghasilan'),
			'jamsoskes' => $this->input->post('jamsoskes'),
			'rt' => $this->input->post('rt'),
			'status_keluarga' => $this->input->post('status_keluarga'),
			'date_created' => $this->input->post('date_created'),
			'date_updated' => $this->input->post('date_updated'),
		);
		$this->M_datawarga->insert__data($data);
		$this->session->set_flashdata('success', 'Data berhasil di inputkan');
	}
}
