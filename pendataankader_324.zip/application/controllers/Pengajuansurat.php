<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengajuansurat extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('M_pengajuan');
		$this->load->model('M_users');
		if ($this->session->useradata('status') != 'login') {
			$this->session->set_flashdata('gagal', 'Maaf, anda harus login terlebih dahulu!');
		}
	}

	public function index()
	{
		$pengajuan = $this->M_pengajuan->pengajuan__by_user()->result();
		$data = array(
			'title' => 'Pengajuan Surat RT/RW',
			'page' => 'pengajuan/index',
			'data' => $pengajuan,
		);
		$this->load->view('web/template', $data);
	}

	public function data_pengajuan()
	{
		$datapengajuan = $this->M_pengajuan->pengajuan__per_rt()->result();
		$data = array(
			'title' => 'Data Pengajuan Surat',
			'page' => 'pengajuan/pengajuanwarga',
			'data' => $datapengajuan,
		);
		$this->load->view('web/template', $data);
	}

	public function ajukan()
	{
		$data = array(
			'title' => 'Form Pengajuan Surat Keterangan',
			'page' => 'pengajuan/ajukan',
		);
		$this->load->view('web/template');
	}

	function kirim__pengajuan_surat_dispensasi()
	{
		$datawarga = $this->M_users->get__detail_user_data()->row();
		$data = array(
			'jenis_surat' => $this->input->post('jenis_surat'),
			'nik' => $this->input->post('nik'),
			'atas_nama' => $this->input->post('atas_nama'),
			'dari_tanggal' => $this->input->post('dari_tanggal'),
			'hingga_tanggal' => $this->input->post('hingga_tanggal'),
			'keterangan' => $this->input->post('keterangan'),
			'tanggal_pengajuan' => date('Y-m-d'),
			'status_surat' => 'Menunggu di Verifikasi',
			'rt' => $datawarga['rt'],
			'id_user' => $this->session->userdata('id_user'),
			'updated_by' => $this->session->userdata('id_user'),
			'date_created' => date('Y-m-d'),
			'date_updated' => date('Y-m-d'),
		);
		if ($this->M_pengajuan->kirim__pengajuan_surat($data)) {
			$this->session->set_flashdata('sukses', 'Berhasil mengajukan surat, silahkan tunggu konfirmasi dari petugas');
			redirect(base_url('pengajuansurat'));
		} else {
			$this->session->set_flashdata('gagal', 'Gagal mengajukan surat, silahkan coba ajukan kembali sesuai format yang diminta');
			redirect(base_url('ajukan'));
		}
	}

	function kirim__pengajuan_surat_kematian()
	{
		$datawarga = $this->M_users->get__detail_user_data()->row();
		$data = array(
			'jenis_surat' => $this->input->post('jenis_surat'),
			'nik' => $this->input->post('nik'),
			'atas_nama' => $this->input->post('atas_nama'),
			'tanggal_meninggal' => $this->input->post('tanggal_meninggal'),
			'tempat_meninggal' => $this->input->post('tempat_meninggal'),
			'nama_pengaju' => $this->input->post('nama_pengaju'),
			'status_pengaju' => $this->input->post('status_pengaju'),
			'keterangan' => $this->input->post('keterangan'),
			'tanggal_pengajuan' => date('Y-m-d'),
			'rt' => $datawarga['rt'],
			'status_surat' => 'Menunggu di Verifikasi',
			'id_user' => $this->session->userdata('id_user'),
			'updated_by' => $this->session->userdata('id_user'),
			'date_created' => date('Y-m-d'),
			'date_updated' => date('Y-m-d'),
		);
		if ($this->M_pengajuan->kirim__pengajuan_surat($data)) {
			$this->session->set_flashdata('sukses', 'Berhasil mengajukan surat, silahkan tunggu konfirmasi dari petugas');
			redirect(base_url('pengajuansurat'));
		} else {
			$this->session->set_flashdata('gagal', 'Gagal mengajukan surat, silahkan coba ajukan kembali sesuai format yang diminta');
			redirect(base_url('ajukan'));
		}
	}

	function kirim__pengajuan_surat_status_penduduk()
	{
		$datawarga = $this->M_users->get__detail_user_data()->row();
		$data = array(
			'jenis_surat' => $this->input->post('jenis_surat'),
			'nik' => $this->input->post('nik'),
			'atas_nama' => $this->input->post('atas_nama'),
			'digunakan_untuk' => $this->input->post('digunakan_untuk'),
			'tanggal_pengajuan' => date('Y-m-d'),
			'status_surat' => 'Menunggu di Verifikasi',
			'keterangan_surat' => 'Pengajuan surat Anda sedang menunggu di verifikasi oleh petugas setempat',
			'rt' => $datawarga['rt'],
			'id_user' => $this->session->userdata('id_user'),
			'updated_by' => $this->session->userdata('id_user'),
			'date_created' => date('Y-m-d'),
			'date_updated' => date('Y-m-d'),
		);
		if ($this->M_pengajuan->kirim__pengajuan_surat($data)) {
			$this->session->set_flashdata('sukses', 'Berhasil mengajukan surat, silahkan tunggu konfirmasi dari petugas');
			redirect(base_url('pengajuansurat'));
		} else {
			$this->session->set_flashdata('gagal', 'Gagal mengajukan surat, silahkan coba ajukan kembali sesuai format yang diminta');
			redirect(base_url('ajukan'));
		}
	}

	public function proses__verifikasi_surat($id_surat)
	{
		if ($this->session->userdata('role') == 'rt' || $this->session->userdata('role') == 'rw') {
			$data = array(
				'status_surat' => 'Sedang di Verifikasi',
				'keterangan_surat' => 'Surat berhasil diverifikasi dan dibuat, silahkan hubungi RT/RW setempat',
				'updated_by' => $this->session->userdata('id_user'),
				'dat_updated' => date('Y-m-d'),
			);
			if ($this->M_pengajuan->prosess__verifikasi_surat($id_user)) {
				$this->session->set_flashdata('sukses', 'Berhasil mengubah status, silahkan lakukan konfirmasi setelah selesai verifikasi');
				redirect(base_url('pengajuansurat'));
			} else {
				$this->session->set_flashdata('gagal', 'Silahkan coba verifikasi ulang');
				redirect(base_url('pengajuansurat'));
			}
		} else {
			$this->session->set_flashdata('gagal', 'Maaf, anda tidak diizinkan untuk mengeksekusi fungsi tersebut!');
			redirect(base_url('pengajuansurat'));
		}
	}

	public function proses__verifikasi_selesai($id_user)
	{
		if ($this->session->userdata('role') == 'rt' || $this->session->userdata('role') == 'rw') {
			$data = array(
				'status_surat' => 'Berhasil Verifikasi',
				'keterangan_surat' => 'Surat berhasil diverifikasi dan dibuat, silahkan hubungi RT/RW setempat',
				'updated_by' => $this->session->userdata('id_user'),
				'dat_updated' => date('Y-m-d'),
			);
			if ($this->M_pengajuan->prosess__verifikasi_selesai($id_user)) {
				$this->session->set_flashdata('sukses', 'Berhasil mengubah status, surat telah selesai di verifikasi');
				redirect(base_url('pengajuansurat'));
			} else {
				$this->session->set_flashdata('gagal', 'Silahkan coba verifikasi ulang');
				redirect(base_url('pengajuansurat'));
			}
		} else {
			$this->session->set_flashdata('gagal', 'Maaf, anda tidak diizinkan untuk mengeksekusi fungsi tersebut!');
			redirect(base_url('pengajuansurat'));
		}
	}

	public function verifikasi__ditolak($id_user)
	{
		if ($this->session->userdata('role') == 'rt' || $this->session->userdata('role') == 'rw') {
			$data = array(
				'status_surat' => 'Pengajuan Surat Ditolak',
				'keterangan_surat' => $this->input->post('keterangan_surat')
				'updated_by' => $this->session->userdata('id_user'),
				'dat_updated' => date('Y-m-d'),
			);
			if ($this->M_pengajuan->verifikasi__ditolak($id_user)) {
				$this->session->set_flashdata('sukses', 'Berhasil mengubah status, surat telah selesai di verifikasi');
				redirect(base_url('pengajuansurat'));
			} else {
				$this->session->set_flashdata('gagal', 'Silahkan coba verifikasi ulang');
				redirect(base_url('pengajuansurat'));
			}
		} else {
			$this->session->set_flashdata('gagal', 'Maaf, anda tidak diizinkan untuk mengeksekusi fungsi tersebut!');
			redirect(base_url('pengajuansurat'));
		}
	}
}
