<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('M_users');
		$userses = $this->session->userdata('username');
	}

	public function index()
	{
		if ($this->session->userdata('status')!='login') {
			$this->load->view('user/login');
		} else {
			redirect(base_url());
		}
	}

	public function login()
	{
		if ($this->session->userdata('status')!='login') {
			$this->load->view('user/login');
		} else {
			redirect(base_url());
		}
	}

	public function login__verify()
	{
		$email = $this->input->post('email');
		$password = sha1(md5('kader'.$this->input->post('password')));
		$datasess = $this->M_users->get__detail_login($email,$password)->num_rows();
		var_dump($datasess);
		$datauser = $this->M_users->get__detail_login($email,$password)->row();
		$datapetugas = $this->M_users->get__detail_data_petugas($email,$password)->row();
		// var_dump($datasess);die();
		if ($datasess > 0 && $datauser->role == 'administrator') {
			$datasession = array(
				'id_user' => $datauser->id_user,
				'username' => $datauser->username,
				'role' => $datauser->role,
				'status' => 'login',
			);
			$this->session->set_userdata($datasession);
			var_dump($datasession);
			// redirect(base_url(''));
		} elseif ($datasess > 0 && $datauser->role == 'kader') {
			$datasession = array(
				'id_user' => $datauser->id_user,
				'username' => $datauser->username,
				'role' => $datauser->role,
				'jabatan' => $datapetugas->jabatan,
				'status' => 'log in',
			);
			$this->session->set_userdata($datasession);
			var_dump($datasession);
			// redirect(base_url());
		} elseif ($datasess > 0 && $datauser->role == 'rt') {
			$datasession = array(
				'id_user' => $datauser->id_user,
				'username' => $datauser->username,
				'role' => $datauser->role,
				'jabatan' => $datapetugas->jabatan,
				'status' => 'log in',
			);
			$this->session->set_userdata($datasession);
			var_dump($datasession);
			// redirect(base_url());
		} elseif ($datasess > 0 && $datauser->role == 'rw') {
			$datasession = array(
				'id_user' => $datauser->id_user,
				'username' => $datauser->username,
				'role' => $datauser->role,
				'jabatan' => $datapetugas->jabatan,
				'status' => 'log in',
			);
			$this->session->set_userdata($datasession);
			var_dump($datasession);
			// redirect(base_url());
		} elseif ($datasess > 0 && $datauser->role == 'warga') {
			$datasession = array(
				'id_user' => $datauser->id_user,
				'username' => $datauser->username,
				'role' => $datauser->role,
				'status' => 'log in',
			);
			$this->session->set_userdata($datasession);
			var_dump($datasession);
			// redirect(base_url());
		} else {
			$this->session->set_flashdata('error', 'Username atau Password Salah');
			echo $this->session->flashdata('error');
			redirect(base_url('auth/login'));
		}
	}

	public function user()
	{
		if ($userses == 'administrator') {
			$datauser = $this->M_users->get__data_user()->result();
			$data = array(
				'title' => 'Daftar User | RW 01 Bojongpeuteuy',
				'page' => 'user/list__user',
				'data' => $datauser,
			);
			$this->load->view('web/template', $data);
		}
	}

	function create__user()
	{
		if ($userses == 'administrator') {
			$data = array(
				'username' => $this->input->post('username'),
				'password' => sha1(md5('kader'.$this->input->post('password'))),
				'email' => $this->input->post('email'),
				'no_hp' => $this->input->post('no_hp'),
				'no_kk' => $this->input->post('no_kk'),
				'role' => $this->input->post('role'),
				'date_created' => date('Y-m-d'),
				'date_updated' => date('Y-m-d'),
			);
			$this->M_users->create__user_data($data);
			$this->session->set_flashdata('sukses','User berhasil dibuat');
			redirect(base_url('user'));
		} else {
			$this->session->set_flashdata('gagal', 'Maaf, anda tidak diizinkan untuk mengakses halaman ini!');
			redirect(base_url(''));
		}
	}

	function update__user($id_user)
	{
		$data = array(
			'username' => $this->input->post('username'),
			'password' => sha1(md5('kader'.$this->input->post('password'))),
			'email' => $this->input->post('email'),
			'no_hp' => $this->input->post('no_hp'),
			'date_updated' => date('Y-m-d'),
		);
		$this->M_users->update__user_data($id_user,$data);
		$this->session->set_flashdata('sukses', 'User berhasil di update');
		redirect(base_url('user'));
	}

	function delete__user($id_user)
	{
		if ($this->M_users->detele__user_data($id_user)) {
			$this->session->set_flashdata('sukses', 'User berhasil di hapus');
			redirect(base_url('user'));
		} else {
			$this->session->set_flashdata('gagal', 'User tidak ditemukan');
			redirect(base_url('user'));
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('auth/login'));
	}

	public function data__user_petugas()
	{
		$data__user = $this->M_users->data__petugas()->result();
		// if ($this->session->userdata('status')!='login') {
		// } else {
		// 	redirect(base_url('user/login'));
		// }
			$data = array(
				'content' => 'admin/list__user_petugas',
				'title' => 'List User',
				'userpetugas' => $data__user,
			);
			$this->load->view('template/content', $data);
	}
}
