<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keluhan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('M_keluhan');
		$this->load->model('M_users');
		if ($this->session->useradata('status') != 'login') {
			$this->session->set_flashdata('gagal', 'Maaf, anda harus login terlebih dahulu!');
		}
	}

	function index()
	{
		if($this->$session->userdata('role') != 'administrator'){
			$this->session->set_flashdata('gagal', 'Maaf, anda tidak diizinkan untuk mengakses halaman tersebut!');
			redirect(base_url());
		} else {
			$keluhan = $this->M_keluhan->get__keluhan()->result();
			$data = array(
				'title' => 'Data Keluhan',
				'page' => 'keluhan/data',
				'data' => $keluhan,
			);
			$this->load->view('web/template', $data);
		}
	}

	function detail__keluhan($id_keluhan)
	{
		$detail__keluhan = $this->M_keluhan->get__detail_keluhan($id_keluhan)->row();
		$data = array(
			'title' => 'Detail Data',
			'page' => 'keluhan/detailkeluhan',
			'data' => $detail__keluhan,
		);
		$this->load->view('web/template', $data);
	}

	function lihat__daftar_keluhan()
	{
		$keluhan_anda = $this->M_keluhan->get__keluhan_warga_by_user()->result();
		$data = array(
			'title' => 'Data Keluhan Anda',
			'page' => 'keluhan/keluhanwarga',
			'data' => $keluhan_anda,
		);
		$this->load->view('web/template', $data);
	}

	function laporkeluhan()
	{
		$data = array(
			'title' => 'Lapor Keluhan',
			'page' => 'keluhan/form__lapor',
		);
		$this->load->view('web/template', $data);
	}

	function kirim__keluhan()
	{
		$datawarga = $this->M_users->get__detail_user_data()->row();
		$data = array(
			'judul_keluhan' => $this->input->post('judul_keluhan'),
			'data_keluhan' => $this->input->post('data_keluhan'),
			'id_user' => $this->session->userdata('id_user'),
			'rt' => $datawarga['rt'],
			'status_keluhan' => 'Menunggu di verifikasi',
			'id_user' => $this->session->userdata('id_user'),
			'updated_by' => $this->session->userdata('id_user'),
			'date_created' => date('Y-m-d'),
			'date_updated' => date('Y-m-d'),
		);
		if ($this->M_keluhan->kirim__keluhan_warga($data)) {
			$this->session->set_flashdata('sukses', 'Sukses melaporkan keluhan');
			echo $this->session->flashdata('sukses');
		} else {
			$this->session->set_flashdata('gagal', 'Gagal melaporkan keluhan, silahkan periksa detail yang kosong');
			echo $this->session->flashdata('gagal');
		}
	}

	function set__proses_keluhan($id_keluhan)
	{
		$data = array(
			'status_keluhan' => 'Diproses',
			'date_updated' => date('Y-m-d'),
			'updated_by' => $this->session->userdata('id_user'),
		);
		$this->M_keluhan->proses__data_keluhan($id_keluhan,$data);
		$this->session->set_flashdata('sukses', 'Data berhasil di update');
		redirect(base_url());
	}

	function set__selesai_proses($id_keluhan)
	{
		$data = array(
			'status_keluhan' => $this->input->post('status_keluhan'),
			'keterangan_status' => $this->input->post('keterangan_status'),
			'date_updated' => date('Y-m-d'),
			'updated_by' => $this->session->userdata('id_user'),
		);
		$this->M_keluhan->proses__data_keluhan($id_keluhan,$data);
		$this->session->set_flashdata('sukses', 'Data berhasil di update');
		redirect(base_url());
	}
}