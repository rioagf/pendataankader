<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/sidebar'); ?>
<?php $this->load->view('template/topbar'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('template/footer'); ?>
