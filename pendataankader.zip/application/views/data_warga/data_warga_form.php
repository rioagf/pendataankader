<section class="d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex align-items-center align-items-sm-center align-items-md-center align-items-lg-center align-items-xl-center features-boxed " style="min-height: 100vh;background: url('../assets/img/8.jpg'); background-size: cover; background-attachment: fixed;">
    <div class="container" style="max-width: 850px;margin-bottom: 100px;">
        <div class="intro">
            <h2 class="text-center">Tambah Data Warga</h2>
            <hr>
        </div>
        <form action="<?php echo $action; ?>" method="post">
            <div class="form-group">
                <label for="int">No KK <?php echo form_error('no_kk') ?></label>
                <input type="text" class="form-control" name="no_kk" id="no_kk" placeholder="No Kk" value="<?php echo $no_kk; ?>" />
            </div>
            <div class="form-group">
                <label for="int">NIK <?php echo form_error('nik') ?></label>
                <input type="text" class="form-control" name="nik" id="nik" placeholder="Nik" value="<?php echo $nik; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Nama Lengkap <?php echo form_error('nama_lengkap') ?></label>
                <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" placeholder="Nama Lengkap" value="<?php echo $nama_lengkap; ?>" />
            </div>
            <div class="form-group">
                <label for="char">Jenis Kelamin <?php echo form_error('jenis_kelamin') ?></label>
                <input type="text" class="form-control" name="jenis_kelamin" id="jenis_kelamin" placeholder="Jenis Kelamin" value="<?php echo $jenis_kelamin; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Tempat Lahir <?php echo form_error('tempat_lahir') ?></label>
                <input type="text" class="form-control" name="tempat_lahir" id="tempat_lahir" placeholder="Tempat Lahir" value="<?php echo $tempat_lahir; ?>" />
            </div>
            <div class="form-group">
                <label for="date">Tanggal Lahir <?php echo form_error('tanggal_lahir') ?></label>
                <input type="text" class="form-control" name="tanggal_lahir" id="tanggal_lahir" placeholder="Tanggal Lahir" value="<?php echo $tanggal_lahir; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Status Perkawinan <?php echo form_error('status_perkawinan') ?></label>
                <input type="text" class="form-control" name="status_perkawinan" id="status_perkawinan" placeholder="Status Perkawinan" value="<?php echo $status_perkawinan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Agama <?php echo form_error('agama') ?></label>
                <input type="text" class="form-control" name="agama" id="agama" placeholder="Agama" value="<?php echo $agama; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Warganegara <?php echo form_error('warganegara') ?></label>
                <input type="text" class="form-control" name="warganegara" id="warganegara" placeholder="Warganegara" value="<?php echo $warganegara; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Pendidikan <?php echo form_error('pendidikan') ?></label>
                <input type="text" class="form-control" name="pendidikan" id="pendidikan" placeholder="Pendidikan" value="<?php echo $pendidikan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Kondisi Pekerjaan <?php echo form_error('kondisi_pekerjaan') ?></label>
                <input type="text" class="form-control" name="kondisi_pekerjaan" id="kondisi_pekerjaan" placeholder="Kondisi Pekerjaan" value="<?php echo $kondisi_pekerjaan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Pekerjaan Utama <?php echo form_error('pekerjaan_utama') ?></label>
                <input type="text" class="form-control" name="pekerjaan_utama" id="pekerjaan_utama" placeholder="Pekerjaan Utama" value="<?php echo $pekerjaan_utama; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Jamsostek <?php echo form_error('jamsostek') ?></label>
                <input type="text" class="form-control" name="jamsostek" id="jamsostek" placeholder="Jamsostek" value="<?php echo $jamsostek; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Penghasilan <?php echo form_error('penghasilan') ?></label>
                <input type="text" class="form-control" name="penghasilan" id="penghasilan" placeholder="Penghasilan" value="<?php echo $penghasilan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Jamsoskes <?php echo form_error('jamsoskes') ?></label>
                <input type="text" class="form-control" name="jamsoskes" id="jamsoskes" placeholder="Jamsoskes" value="<?php echo $jamsoskes; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">RT <?php echo form_error('rt') ?></label>
                <input type="text" class="form-control" name="rt" id="rt" placeholder="Rt" value="<?php echo $rt; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Status Keluarga <?php echo form_error('status_keluarga') ?></label>
                <input type="text" class="form-control" name="status_keluarga" id="status_keluarga" placeholder="Status Keluarga" value="<?php echo $status_keluarga; ?>" />
            </div>

            <div class="form-group">
                <label for="varchar">Tempat Tinggal <?php echo form_error('tempat_tinggal') ?></label>
                <input type="text" class="form-control" name="tempat_tinggal" id="tempat_tinggal" placeholder="Tempat Tinggal" value="<?php echo $tempat_tinggal; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Status Lahan <?php echo form_error('status_lahan') ?></label>
                <input type="text" class="form-control" name="status_lahan" id="status_lahan" placeholder="Status Lahan" value="<?php echo $status_lahan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Luas Lantai <?php echo form_error('luas_lantai') ?></label>
                <input type="text" class="form-control" name="luas_lantai" id="luas_lantai" placeholder="Luas Lantai" value="<?php echo $luas_lantai; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Luas Lahan <?php echo form_error('luas_lahan') ?></label>
                <input type="text" class="form-control" name="luas_lahan" id="luas_lahan" placeholder="Luas Lahan" value="<?php echo $luas_lahan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Jenis Lantai <?php echo form_error('jenis_lantai') ?></label>
                <input type="text" class="form-control" name="jenis_lantai" id="jenis_lantai" placeholder="Jenis Lantai" value="<?php echo $jenis_lantai; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Dinding <?php echo form_error('dinding') ?></label>
                <input type="text" class="form-control" name="dinding" id="dinding" placeholder="Dinding" value="<?php echo $dinding; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Jendela <?php echo form_error('jendela') ?></label>
                <input type="text" class="form-control" name="jendela" id="jendela" placeholder="Jendela" value="<?php echo $jendela; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Genteng <?php echo form_error('genteng') ?></label>
                <input type="text" class="form-control" name="genteng" id="genteng" placeholder="Genteng" value="<?php echo $genteng; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Penerangan <?php echo form_error('penerangan') ?></label>
                <input type="text" class="form-control" name="penerangan" id="penerangan" placeholder="Penerangan" value="<?php echo $penerangan; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Energi Memasak <?php echo form_error('energi_memasak') ?></label>
                <input type="text" class="form-control" name="energi_memasak" id="energi_memasak" placeholder="Energi Memasak" value="<?php echo $energi_memasak; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Tps <?php echo form_error('tps') ?></label>
                <input type="text" class="form-control" name="tps" id="tps" placeholder="Tps" value="<?php echo $tps; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Mck <?php echo form_error('mck') ?></label>
                <input type="text" class="form-control" name="mck" id="mck" placeholder="Mck" value="<?php echo $mck; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Sumber Airmandi <?php echo form_error('sumber_airmandi') ?></label>
                <input type="text" class="form-control" name="sumber_airmandi" id="sumber_airmandi" placeholder="Sumber Airmandi" value="<?php echo $sumber_airmandi; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Fasilitas Bab <?php echo form_error('fasilitas_bab') ?></label>
                <input type="text" class="form-control" name="fasilitas_bab" id="fasilitas_bab" placeholder="Fasilitas Bab" value="<?php echo $fasilitas_bab; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Sumber Airminum <?php echo form_error('sumber_airminum') ?></label>
                <input type="text" class="form-control" name="sumber_airminum" id="sumber_airminum" placeholder="Sumber Airminum" value="<?php echo $sumber_airminum; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Pembuangan Limbah <?php echo form_error('pembuangan_limbah') ?></label>
                <input type="text" class="form-control" name="pembuangan_limbah" id="pembuangan_limbah" placeholder="Pembuangan Limbah" value="<?php echo $pembuangan_limbah; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Bawah Sutet <?php echo form_error('bawah_sutet') ?></label>
                <input type="text" class="form-control" name="bawah_sutet" id="bawah_sutet" placeholder="Bawah Sutet" value="<?php echo $bawah_sutet; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Bantaran Sungai <?php echo form_error('bantaran_sungai') ?></label>
                <input type="text" class="form-control" name="bantaran_sungai" id="bantaran_sungai" placeholder="Bantaran Sungai" value="<?php echo $bantaran_sungai; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Lerang <?php echo form_error('lerang') ?></label>
                <input type="text" class="form-control" name="lerang" id="lerang" placeholder="Lerang" value="<?php echo $lerang; ?>" />
            </div>
            <div class="form-group">
                <label for="varchar">Kondisi Rumah <?php echo form_error('kondisi_rumah') ?></label>
                <input type="text" class="form-control" name="kondisi_rumah" id="kondisi_rumah" placeholder="Kondisi Rumah" value="<?php echo $kondisi_rumah; ?>" />
            </div>
            <input type="hidden" name="id_data_warga" value="<?php echo $id_data_warga; ?>" /> 
            <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
            <a href="<?php echo site_url('data_warga') ?>" class="btn btn-default">Cancel</a>
        </form>
    </div>
</section>
<nav class="navbar navbar-light navbar-expand fixed-bottom" style="background: rgba(66,0,98,0.5);box-shadow: 0px 2px 15px 0px;padding: 7px 2px;">
    <div class="container">
        <section class="d-flex justify-content-center" style="width: 100%;">
            <div class="row" style="width: 100%;">
                <div class="col text-center" style="width: 33.3333%;">
                    <a class="stretched-link" href="<?= base_url() ?>" style="color: rgb(255,255,255);">
                        <i class="fa fa-home" style="padding: 0;font-size: 26px;width: 100%;"></i>
                        <p style="margin-bottom: 0;">HOME</p>
                    </a>
                </div>
                <div class="col text-center" style="width: 33.3333%;">
                    <a href="<?= base_url('data_warga') ?>" style="color: rgb(255,255,255);">
                        <i class="fa fa-users" style="padding: 0;font-size: 26px;width: 100%;"></i>
                        <p style="margin-bottom: 0;">DATA WARGA</p>
                    </a>
                </div>
                <div class="col text-center" style="width: 33.3333%;">
                    <a href="#" style="color: rgb(255,255,255);">
                        <i class="fa fa-sign-out" style="padding: 0;font-size: 26px;width: 100%;"></i>
                        <p style="margin-bottom: 0;">LOGOUT</p>
                    </a>
                </div>
            </div>
        </section>
    </div>
</nav>