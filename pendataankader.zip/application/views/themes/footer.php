    <script src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
    <script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    <script>
    	$(document).ready( function () {
    		$('#table_data').DataTable();
    	} );
    </script>

    <script type="text/javascript">
    	$("#jenis_surat").change(function() {
    		if ($(this).val() == "surat kematian") {
    			$('#kematian').show();
    			$('#domisili').hide();
    			$('#dispensasi').hide();
    			$('#nama_yang_meninggal').attr('required', '');
    			$('#nama_yang_meninggal').attr('data-error', 'This field is required.');
    			$('#tanggal_kematian').attr('required', '');
    			$('#tanggal_kematian').attr('data-error', 'This field is required.');
    			$('#faktor_kematian').attr('required', '');
    			$('#faktor_kematian').attr('data-error', 'This field is required.');
    			$('#tanggal_dispensasi').removeAttr('required');
    			$('#tanggal_dispensasi').removeAttr('data-error');
    			$('#sampai_tanggal_dispensasi').removeAttr('required');
    			$('#sampai_tanggal_dispensasi').removeAttr('data-error');
    			$('#jumlah_hari').removeAttr('required');
    			$('#jumlah_hari').removeAttr('data-error');
    			$('#alasan_dispen').removeAttr('required');
    			$('#alasan_dispen').removeAttr('data-error');
    		} else if ($(this).val() == "surat dispensasi"){
    			$('#kematian').hide();
    			$('#domisili').hide();
    			$('#dispensasi').show();
    			$('#tanggal_dispensasi').attr('required', '');
    			$('#tanggal_dispensasi').attr('data-error', 'This field is required.');
    			$('#sampai_tanggal_dispensasi').attr('required', '');
    			$('#sampai_tanggal_dispensasi').attr('data-error', 'This field is required.');
    			$('#jumlah_hari').attr('required', '');
    			$('#jumlah_hari').attr('data-error', 'This field is required.');
    			$('#alasan_dispen').attr('required', '');
    			$('#alasan_dispen').attr('data-error', 'This field is required.');
    			$('#nama_yang_meninggal').removeAttr('required');
    			$('#nama_yang_meninggal').removeAttr('data-error');
    			$('#tanggal_kematian').removeAttr('required');
    			$('#tanggal_kematian').removeAttr('data-error');
    			$('#faktor_kematian').removeAttr('required');
    			$('#faktor_kematian').removeAttr('data-error');
    		} else if ($(this).val() == "surat domisili"){
    			$('#kematian').hide();
    			$('#domisili').show();
    			$('#dispensasi').hide();

    			$('#nama_yang_meninggal').removeAttr('required');
    			$('#nama_yang_meninggal').removeAttr('data-error');
    			$('#tanggal_kematian').removeAttr('required');
    			$('#tanggal_kematian').removeAttr('data-error');
    			$('#faktor_kematian').removeAttr('required');
    			$('#faktor_kematian').removeAttr('data-error');
    			
    			$('#tanggal_dispensasi').removeAttr('required');
    			$('#tanggal_dispensasi').removeAttr('data-error');
    			$('#sampai_tanggal_dispensasi').removeAttr('required');
    			$('#sampai_tanggal_dispensasi').removeAttr('data-error');
    			$('#jumlah_hari').removeAttr('required');
    			$('#jumlah_hari').removeAttr('data-error');
    			$('#alasan_dispen').removeAttr('required');
    			$('#alasan_dispen').removeAttr('data-error');
    		}
    	});
    	$("#jenis_surat").trigger("change");
    </script>
</body>

</html>