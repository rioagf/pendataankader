<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Penerima_bantuan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Penerima_bantuan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'penerima_bantuan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'penerima_bantuan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'penerima_bantuan/index.html';
            $config['first_url'] = base_url() . 'penerima_bantuan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Penerima_bantuan_model->total_rows($q);
        $penerima_bantuan = $this->Penerima_bantuan_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'penerima_bantuan_data' => $penerima_bantuan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('penerima_bantuan/penerima_bantuan_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Penerima_bantuan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_penerima' => $row->id_penerima,
		'no_kk' => $row->no_kk,
		'nik' => $row->nik,
		'nama_penerima' => $row->nama_penerima,
		'rt' => $row->rt,
		'jenis_bantuan' => $row->jenis_bantuan,
		'tanggal_generate_penerima' => $row->tanggal_generate_penerima,
		'date_created' => $row->date_created,
		'date_updated' => $row->date_updated,
		'id_user' => $row->id_user,
	    );
            $this->load->view('penerima_bantuan/penerima_bantuan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penerima_bantuan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('penerima_bantuan/create_action'),
	    'id_penerima' => set_value('id_penerima'),
	    'no_kk' => set_value('no_kk'),
	    'nik' => set_value('nik'),
	    'nama_penerima' => set_value('nama_penerima'),
	    'rt' => set_value('rt'),
	    'jenis_bantuan' => set_value('jenis_bantuan'),
	    'tanggal_generate_penerima' => set_value('tanggal_generate_penerima'),
	    'date_created' => set_value('date_created'),
	    'date_updated' => set_value('date_updated'),
	    'id_user' => set_value('id_user'),
	);
        $this->load->view('penerima_bantuan/penerima_bantuan_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'no_kk' => $this->input->post('no_kk',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'nama_penerima' => $this->input->post('nama_penerima',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'jenis_bantuan' => $this->input->post('jenis_bantuan',TRUE),
		'tanggal_generate_penerima' => $this->input->post('tanggal_generate_penerima',TRUE),
		'date_created' => $this->input->post('date_created',TRUE),
		'date_updated' => $this->input->post('date_updated',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
	    );

            $this->Penerima_bantuan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('penerima_bantuan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Penerima_bantuan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('penerima_bantuan/update_action'),
		'id_penerima' => set_value('id_penerima', $row->id_penerima),
		'no_kk' => set_value('no_kk', $row->no_kk),
		'nik' => set_value('nik', $row->nik),
		'nama_penerima' => set_value('nama_penerima', $row->nama_penerima),
		'rt' => set_value('rt', $row->rt),
		'jenis_bantuan' => set_value('jenis_bantuan', $row->jenis_bantuan),
		'tanggal_generate_penerima' => set_value('tanggal_generate_penerima', $row->tanggal_generate_penerima),
		'date_created' => set_value('date_created', $row->date_created),
		'date_updated' => set_value('date_updated', $row->date_updated),
		'id_user' => set_value('id_user', $row->id_user),
	    );
            $this->load->view('penerima_bantuan/penerima_bantuan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penerima_bantuan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_penerima', TRUE));
        } else {
            $data = array(
		'no_kk' => $this->input->post('no_kk',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'nama_penerima' => $this->input->post('nama_penerima',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'jenis_bantuan' => $this->input->post('jenis_bantuan',TRUE),
		'tanggal_generate_penerima' => $this->input->post('tanggal_generate_penerima',TRUE),
		'date_created' => $this->input->post('date_created',TRUE),
		'date_updated' => $this->input->post('date_updated',TRUE),
		'id_user' => $this->input->post('id_user',TRUE),
	    );

            $this->Penerima_bantuan_model->update($this->input->post('id_penerima', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('penerima_bantuan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Penerima_bantuan_model->get_by_id($id);

        if ($row) {
            $this->Penerima_bantuan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('penerima_bantuan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penerima_bantuan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('no_kk', 'no kk', 'trim|required');
	$this->form_validation->set_rules('nik', 'nik', 'trim|required');
	$this->form_validation->set_rules('nama_penerima', 'nama penerima', 'trim|required');
	$this->form_validation->set_rules('rt', 'rt', 'trim|required');
	$this->form_validation->set_rules('jenis_bantuan', 'jenis bantuan', 'trim|required');
	$this->form_validation->set_rules('tanggal_generate_penerima', 'tanggal generate penerima', 'trim|required');
	$this->form_validation->set_rules('date_created', 'date created', 'trim|required');
	$this->form_validation->set_rules('date_updated', 'date updated', 'trim|required');
	$this->form_validation->set_rules('id_user', 'id user', 'trim|required');

	$this->form_validation->set_rules('id_penerima', 'id_penerima', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Penerima_bantuan.php */
/* Location: ./application/controllers/Penerima_bantuan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2021-08-11 09:15:13 */
/* http://harviacode.com */